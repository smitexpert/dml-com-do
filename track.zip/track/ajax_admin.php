<?php

require_once 'Database.php';

$db = new Database;


if(isset($_POST['dml'])){
    $dml = $_POST['dml'];
    $org = $_POST['org'];
    
    $sql = "INSERT INTO test_track (dml_awn, org_awn) VALUES ('$dml', '$org')";
    $query = $db->link->query($sql);
    if($query){
        echo 1;
    }else{
        echo 0;
    }
}

if(isset($_POST['dlt_id'])){
    $id = $_POST['dlt_id'];
    $sql = "DELETE FROM test_track WHERE id='$id'";
    $query = $db->link->query($sql);
    if($query){
        echo 1;
    }else{
        echo 0;
    }
}


?>
<?php
require_once 'Database.php';

$db = new Database;

session_start();

if(isset($_GET['logout'])){
    session_unset();
    session_destroy();
}

if(isset($_SESSION['trk_login'])){
    $login = 1;
}else{
    $login = 0;
}

if(isset($_POST['username'])){
    $username = $_POST['username'];
    $password = $_POST['password'];
    
    if(($username == 'admin') && ($password == 'dml_admin')){
        $_SESSION['trk_login'] = true;
        header("location: admin.php");
    }else{
        session_unset();
        session_destroy();
        header("location: admin.php?error");
    }
    
}

$er = 0;

if(isset($_GET['error'])){
    $er = 1;
}

?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Admin - DML Shipment Tracking</title>
    <link rel="stylesheet" href="jquery.dataTables.min.css">
    <link rel="stylesheet" href="bootstrap/css/bootstrap.min.css">
    <link rel="stylesheet" href="admin_style.css">
</head>

<body>

    <div class="container">

        <?php if($login == 0 ){ ?>
        <div class="login">
            <div class="row">
                <div class="col-md-4"></div>
                <div class="col-md-4">
                    <?php
                    if($er == 1){
                        ?>
                    <div class="alert alert-danger">
                        <strong>Error!</strong> Username Password Incurrect!
                    </div>
                    <?php
                    }
                    ?>
                    <form action="admin.php" method="post" id="login_form">
                        <h2>Tracking Panel Login</h2>
                        <div class="form-group">
                            <label for="">Username</label>
                            <input type="text" name="username" class="form-control" required>
                        </div>
                        <div class="form-group">
                            <label for="">Password</label>
                            <input type="password" name="password" class="form-control" required>
                        </div>
                        <button type="submit" class="btn btn-block btn-sm btn-warning">LOGIN</button>
                    </form>
                    <br>
                    <a href="index.php">Back to Track</a>
                </div>
                <div class="col-md-4"></div>
            </div>
        </div>

        <?php }else{ ?>

        <nav class="navbar navbar-inverse">
            <div class="container-fluid">
                <div class="navbar-header">
                    <a class="navbar-brand" href="admin.php">DML Tracking</a>
                </div>
                <ul class="nav navbar-nav">
                    <li class="active"><a href="admin.php">Admin Panel</a></li>
                    <li><a href="admin.php?logout">Logout</a></li>
                    <li><a href="index.php">Visit Tracker</a></li>
                </ul>
            </div>
        </nav>

        <div class="row">
            <div class="col-md-6">
                <div class="row">
                    <form class="" id="awn_form">
                        <div class="col-md-6">
                            <div class="form-group">
                                <label for="dml">DML AWN:</label>
                                <input type="text" class="form-control" id="dml" placeholder="Enter DML AWN" name="dml" required>
                            </div>
                        </div>
                        <div class="col-md-6">
                            <div class="form-group">
                                <label for="org">ORG AWN:</label>
                                <input type="text" class="form-control" id="org" placeholder="Enter ORG AWN" name="org" required>
                            </div>
                        </div>
                        <div class="col-md-6"></div>
                        <div class="col-md-6">
                            <button type="submit" class="btn btn-default pull-right">Submit</button>
                        </div>

                    </form>
                </div>
            </div>
            <div class="col-md-6">
                <div class="row">
                    <div class="col-md-12">
                       <table class="table" id="datatable">
                           <thead>
                               <tr>
                                  <th>ID</th>
                                   <th>DML AWN</th>
                                   <th>ORG. AWN</th>
                                   <th>Action</th>
                               </tr>
                           </thead>
                           <tbody>
                               <?php
                    
                                    $sql = "SELECT * FROM test_track ORDER BY id DESC";
                                    $query = $db->link->query($sql);
                                    if($query->num_rows > 0){
                                        while($row = $query->fetch_assoc()){
                                            ?>
                                            <tr>
                                                <td><?php echo $row['id']; ?></td>
                                                <td><?php echo $row['dml_awn']; ?></td>
                                                <td><?php echo $row['org_awn']; ?></td>
                                                <td><button id="<?php echo $row['id']; ?>" class="btn btn-sm btn-danger dlt_cls"><span class="glyphicon glyphicon-trash"></span></button></td>
                                            </tr>
                                            <?php
                                        }
                                    }

                                ?>
                           </tbody>
                       </table>
                        
                    </div>
                </div>
            </div>
        </div>

        <?php } ?>

    </div>


    <script src="jquery-3.3.1.min.js"></script>
    <script src="bootstrap/js/bootstrap.min.js"></script>
    <script src="jquery.dataTables.min.js"></script>
    <script>
        
        $("#datatable").DataTable({
            "order": [[ 0, "desc" ]],
            
            "columnDefs": [
                {
                    "targets": [ 0 ],
                    "visible": false,
                    "searchable": false
                }
            ]
        });
        
        $("#awn_form").on('submit', function(e){
            e.preventDefault();
            var awn_form = $(this).serialize();
            
            $.ajax({
                url: "ajax_admin.php",
                method: "POST",
                data: awn_form,
                success: function(data){
                    if(data == '1'){
                        alert("Inserted!!!");
                        document.getElementById("awn_form").reset();
                    }
                    
                    else{
                        alert("DML AWN already Exist!!!");
                    }
                        
                }
            });
        });
        
        $(".dlt_cls").click(function(e){
            var id = $(this).closest('td').find('button').attr("id");
           
            var conf = confirm("Do you want to Delete?");
            if(conf == true){
                $.ajax({
                    url: "ajax_admin.php",
                    method: "POST",
                    data: { dlt_id: id },
                    success: function(data){
                        if(data == 1){
                            $(e.target).closest('tr').remove();
                        }else{
                            alert("Opps!!! Try again.");
                        }
                    }
                })
            }
        })
    </script>
</body>

</html>

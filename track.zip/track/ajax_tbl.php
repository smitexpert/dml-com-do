<!--<table class="table tbl_one">
    <caption>Tracking Result</caption>
    <tr>
        <td style="width: 130px;">Consignment No.</td>
        <td style="width: 10px;">:</td>
        <td>201812957</td>
    </tr>
    <tr>
        <td>Ref No.</td>
        <td>:</td>
        <td></td>
    </tr>
</table>
<table class="table tbl_two">
    <caption>Current Activity</caption>
    <tr>
        <td>Shipment Connected With FEDEX with Ref # 478290518730</td>
    </tr>
</table>
<table class="table tbl_three">
    <caption>Shipment Details of 201812957</caption>
    <tr>
        <td style="width: 40px;">Origin</td>
        <td style="width: 10px;">:</td>
        <td style="width: 50%;">BANGLADESH</td>
        <td style="width: 40px;">Destination</td>
        <td style="width: 10px;">:</td>
        <td>U.S.A</td>
    </tr>
    <tr>
        <td style="width: 40px;">Services</td>
        <td style="width: 10px;">:</td>
        <td style="width: 50%;">FEDEX</td>
        <td style="width: 40px;">Ship Content</td>
        <td style="width: 10px;">:</td>
        <td>SPX</td>
    </tr>
    <tr>
        <td style="width: 40px;">Pcs</td>
        <td style="width: 10px;">:</td>
        <td style="width: 50%;">1</td>
        <td style="width: 40px;">Booking Date</td>
        <td style="width: 10px;">:</td>
        <td>12 July 2019</td>
    </tr>
</table>
<table class="table tbl_four">
    <tr>
        <th>Shipper Details</th>
        <th>Consignee Details</th>
    </tr>
    <tr>
        <td>SHAKHAWAT HOSSAIN</td>
        <td>SHOBUJ ISLAM</td>
    </tr>
</table>
<table class="table tbl_five">
    <tr>
        <th>Tracking Progress :</th>
    </tr>
</table>-->
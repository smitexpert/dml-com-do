<?php
require_once 'Database.php';

$db = new Database;


include('php-tracking-urls.php');
include('dhl_track.php');
include('fed_track.php');

if(isset($_GET['awn'])){
    $awn = $_GET['awn'];
    
    $sql = "SELECT * FROM test_track WHERE dml_awn='$awn'";
    $query = $db->link->query($sql);
    if($query->num_rows > 0){
        $row = $query->fetch_assoc();
        $org_awn =$row['org_awn'];
        $company_name = get_tracking($org_awn);

        if($company_name == "DHL"){
            dhl_tracking($awn, $org_awn);
        }elseif($company_name == "FEDEX"){
            fedex_tracking($awn, $org_awn);
        }
    }else{
        echo '0';
    }
    
}



?>




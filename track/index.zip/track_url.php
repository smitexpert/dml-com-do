<?php

function getTrackUrl($val, $awn){
    $url = [
        'DHL'=>'http://www.dhl.com/content/g0/en/express/tracking.shtml?brand=DHL&AWB='.$awn,
        'FEDEX' => 'http://www.fedex.com/Tracking?language=english&cntry_code=us&tracknumbers='.$awn
    ];
    
    
    
    if(isset($url[$val])){
        return $url[$val];
    }else{
        return false;
    }
}

?>
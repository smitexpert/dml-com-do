# AramexShipmentTrackingAPI
Aramex Shipment Tracking API using simple PHP

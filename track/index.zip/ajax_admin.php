<?php

require_once 'Database.php';

$db = new Database;


if(isset($_POST['dml'])){
    $dml = $_POST['dml'];
    $org = $_POST['org'];
    $principal = $_POST['principal'];
    $shipper_name = $_POST['shipper_name'];
    $origin = $_POST['origin'];
    $destination = $_POST['destination'];
    $consignee_name = $_POST['consignee_name'];
    $pcs = $_POST['pcs'];
    $ship_content = $_POST['ship_content'];
    $booking_date = $_POST['booking_date'];
    
    $sql = "INSERT INTO test_track (dml_awn, org_awn, principal, shipper_name, origin, destination, consignee_name, pcs, ship_content, booking_date, status) VALUES ('$dml', '$org', '$principal', '$shipper_name', '$origin', '$destination', '$consignee_name', '$pcs', '$ship_content', '$booking_date', '1')";
    $query = $db->link->query($sql);
    if($query){
        echo 1;
    }else{
        echo 0;
//        echo $db->link->error;
    }
}

if(isset($_POST['dlt_id'])){
    $id = $_POST['dlt_id'];
    $sql = "DELETE FROM test_track WHERE dml_awn='$id'";
    $query = $db->link->query($sql);
    if($query){
        echo 1;
    }else{
        echo 0;
    }
}

if(isset($_POST['org_up_id'])){
    $id = $_POST['org_up_id'];
    $org = $_POST['org_up'];
    
    $sql = "UPDATE test_track SET org_awn='$org' WHERE dml_awn='$id'";
    $query = $db->link->query($sql);
    if($query){
        echo '1';
    }else{
        echo '0';
    }
}


?>
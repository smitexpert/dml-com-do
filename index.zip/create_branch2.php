<?php
    header("location: createBranch.php");
    exit(); 
?>
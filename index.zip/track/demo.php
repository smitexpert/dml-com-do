<?php
include('track_url.php');

$val = getTrackUrl('FIRSTFLIGHT', '120');

print_r($val);

?>
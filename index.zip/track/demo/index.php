<?php

// Just to run the trackingPHP.php. 
// You can just straightly call the trackingPHP.php without this index.php

include 'trackingPHP.php';


?>
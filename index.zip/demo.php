<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Document</title>
</head>
<body>
    <form action="">
        <input type="email" required>
        <button type="submit">SUBMIT</button>
    </form>
</body>
</html>
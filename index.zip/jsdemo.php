<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <title>Document</title>
</head>

<body>

    <p>
        25 pic.
    </p>
    
    <script src="assets/jQuery/jquery-3.3.1.min.js"></script>
    <script>
        var num = $("p").text();
        console.log(parseInt(num));
        
    </script>
</body>

</html>

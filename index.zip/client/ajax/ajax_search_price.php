<?php
include("../../lib/Session.php");
include("../../lib/Database.php");



Session::checkAgentSession();

$agent_email = Session::get('agent_email');
$db = new Database();

if(isset($_POST['country_tag'])){
    $agent_email = Session::get('agent_email');
    $country_tag =  $_POST['country_tag'];
    $weight =  $_POST['weight'];

    //get price from agent_client_price Document
    $getAgentPrice = "SELECT agent_client_price.*, principals_name.principal_name FROM agent_client_price INNER JOIN dml_zone ON agent_client_price.zone = dml_zone.zone INNER JOIN principals_name ON agent_client_price.principal_id = principals_name.id WHERE dml_zone.country_tag = '$country_tag' AND agent_client_price.weight = '$weight' AND agent_client_price.agent_client_email = '$agent_email' AND agent_client_price.goods_type = 'D' AND agent_client_price.price > 0 ORDER BY agent_client_price.price ASC";

    $getPrice = $db->link->query($getAgentPrice);

    //get special price

    $getAgentSpecialPrice = "SELECT agent_client_special_rate.*, principals_name.principal_name FROM agent_client_special_rate INNER JOIN principals_name ON agent_client_special_rate.principal_id = principals_name.id WHERE agent_client_special_rate.country_tag = '$country_tag' AND agent_client_special_rate.weight = '$weight' AND agent_client_special_rate.agent_client_email = '$agent_email' AND agent_client_special_rate.goods_type = 'D' AND agent_client_special_rate.price > 0 ORDER BY agent_client_special_rate.price ASC";

    $getSpecialPrice = $db->link->query($getAgentSpecialPrice);


    //get price from agent_client_price Percel
    $getAgentPrice_P = "SELECT agent_client_price.*, principals_name.principal_name FROM agent_client_price INNER JOIN dml_zone ON agent_client_price.zone = dml_zone.zone INNER JOIN principals_name ON agent_client_price.principal_id = principals_name.id WHERE dml_zone.country_tag = '$country_tag' AND agent_client_price.weight = '$weight' AND agent_client_price.agent_client_email = '$agent_email' AND agent_client_price.goods_type = 'P' AND agent_client_price.price > 0 ORDER BY agent_client_price.price ASC";

    $getPrice_P = $db->link->query($getAgentPrice_P);

    //get special price for Percel

    $getAgentSpecialPrice_P = "SELECT agent_client_special_rate.*, principals_name.principal_name FROM agent_client_special_rate INNER JOIN principals_name ON agent_client_special_rate.principal_id = principals_name.id WHERE agent_client_special_rate.country_tag = '$country_tag' AND agent_client_special_rate.weight = '$weight' AND agent_client_special_rate.agent_client_email = '$agent_email' AND agent_client_special_rate.goods_type = 'P' AND agent_client_special_rate.price > 0 ORDER BY agent_client_special_rate.price ASC";

    $getSpecialPrice_P = $db->link->query($getAgentSpecialPrice_P);

    // echo $getAgentSpecialPrice;

?>
    <div class="all_price">
    <table class="table table-striped table-bordered table-hover">
        <caption style="text-align: left;font-size: 18px;font-weight: bold;color: green;">DOX</caption>
        <tr>
            <th rowspan="2" style="text-align:center">Principal Name</th>
            <th rowspan="2" style="text-align:center">Weight(kg)</th>
            <th colspan="2" style="text-align:center">GENERAL PRICE</th>
            <th colspan="2" style="text-align:center">SPECIAL PRICE</th>
        </tr>
        <tr>
            <th style="text-align:center">PRICE (USD)</th>
            <th style="text-align:center">PRICE (BDT)</th>
            <th style="text-align:center">PRICE (USD)</th>
            <th style="text-align:center">PRICE (BDT)</th>
        </tr>

        <?php
    
    while($getPrice_D = $getPrice->fetch_assoc()){
            $getSpecialPrice_D = $getSpecialPrice->fetch_assoc();
            ?>
        <tr style="font-size: 18px;background-color: yellow;color: red; font-weight: bold;">
            <td title="Lowest Price"><?php echo $getPrice_D['principal_name']; ?></td>
            <td style="text-align:center"><?php echo $weight; ?></td>
            <td style="text-align: right;"><?php echo $getPrice_D['price']; ?></td>
            <td style="text-align: right;"><?php echo $db->converttobdt('usd', $getPrice_D['price']); ?></td>
            
            <td style="text-align: right;"><?php echo $getSpecialPrice_D['price']; ?></td>
            <td style="text-align: right;"><?php echo $db->converttobdt('usd', $getSpecialPrice_D['price']); ?></td>
        </tr>
        <?php
    }
    
    if($getPrice_P){
?>

    </table>
    <table class="table table-striped table-bordered table-hover">
        <caption style="text-align: left;font-size: 22px;font-weight: bold;color: green;">SPX</caption>
        <tr>
            <th rowspan="2" style="text-align:center">Principal Name</th>
            <th rowspan="2" style="text-align:center">Weight(kg)</th>
            <th colspan="2" style="text-align:center">GENERAL PRICE</th>
            <th colspan="2" style="text-align:center">SPECIAL PRICE</th>
        </tr>
        <tr>
            <th style="text-align:center">PRICE (USD)</th>
            <th style="text-align:center">PRICE (BDT)</th>
            <th style="text-align:center">PRICE (USD)</th>
            <th style="text-align:center">PRICE (BDT)</th>
        </tr>

        <?php
    
    while($getPrice_PP = $getPrice_P->fetch_assoc()){
        $getSpecialPrice_PP = $getSpecialPrice_P->fetch_assoc();
        ?>
    <tr style="font-size: 18px;background-color: yellow;color: red; font-weight: bold;">
        <td title="Lowest Price"><?php echo $getPrice_PP['principal_name']; ?></td>
        <td style="text-align:center"><?php echo $weight; ?></td>
        <td style="text-align: right;"><?php echo $getPrice_PP['price']; ?></td>
        <td style="text-align: right;"><?php echo $db->converttobdt('usd', $getPrice_PP['price']); ?></td>
        
        <td style="text-align: right;"><?php echo $getSpecialPrice_PP['price']; ?></td>
        <td style="text-align: right;"><?php echo $db->converttobdt('usd', $getSpecialPrice_PP['price']); ?></td>
    </tr>
            <?php
        }
        }
    
?>

    </table>
</div>

<?php
}
?>
<?php 
define("DB_HOST", "localhost");
define("DB_USER","udukhfmy_mbr");
define("DB_PASS","se5CRHybt5qSM7Ic");
define("DB_NAME", "udukhfmy__dml_intl");
?>
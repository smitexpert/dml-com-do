<?php

$num = (int) 0;

echo $num;

?>
<div class="navbar-content">
				<!-- start: SIDEBAR -->
				<div class="main-navigation navbar-collapse collapse">
					<!-- start: MAIN MENU TOGGLER BUTTON -->
					<div class="navigation-toggler">
						<i class="clip-chevron-left"></i>
						<i class="clip-chevron-right"></i>
					</div>
					<!-- end: MAIN MENU TOGGLER BUTTON -->
					<!-- start: MAIN NAVIGATION MENU -->
					
					<nav>
					<ul id="nav" class="main-navigation-menu">
                        <li class="linav">
							<a href="index.php"><i class="clip-screen"></i>
								<span class="title">DASHBOARD</span>
							</a>
                        </li>
										


						<!-- <li class="linav">
							<a href="javascript:void(0)"><i class="clip-screen"></i>
								<span class="title"> Consignment Area</span><i class="icon-arrow"></i>
								<span class="selected"></span>
							</a>
							<ul class="sub-menu">
								<li>
									<a class="nav" href="client_consignment_booking.php">
										<span class="title">Consignment Booking</span>
									</a>
								</li>
								<li>
									<a href="client_consignment_list.php">
										<span class="title">Consignment List</span>
									</a>
								</li>								

								<li>
									<a href="client_consignment_history.php">
										<span class="title">Consignment History</span>
									</a>
								</li>	

							</ul>
						</li>						 -->

						<li class="linav">
							<a href="search_price.php">
								<span class="title">SEARCH PRICE</span>
							</a>
						</li>
						
						<li class="linav">
							<a href="booking.php">
								<span class="title">CONSIGNMENT BOOKING</span>
							</a>
						</li>
						<li class="linav">
							<a href="consignment_view.php">
								<span class="title">CONSIGNMENT LIST</span>
							</a>
						</li>
						
						<li class="linav">
							<a class="nav" href="agent_client_view_price.php">
								<span class="title">VIEW ALL PRICE</span>
							</a>
						</li>
						<li class="linav">
							<a class="nav" href="agent_accounts.php">
								<span class="title">ACCOUNTS</span>
							</a>
						</li>
						<li class="linav">
							<a class="nav" href="agent_settings.php">
								<span class="title">SETTINGS</span>
							</a>
						</li>
						<!-- <li class="linav">
							<a href="client_view_special_price.php">
								<span class="title">Booking</span>
							</a>
						</li> -->
												


						<!-- <li class="linav">
							<a href="client_accounts.php"><i class="clip-screen"></i>
								<span class="title">Accounts</span>
							</a>
				        </li>						 -->


						<!-- <li class="linav">
							<a href="javascript:void(0)"><i class="clip-user-2"></i>
								<span class="title">Settings</span><i class="icon-arrow"></i>
								<span class="selected"></span>
							</a>
							<ul class="sub-menu">
								<li>
									<a class="nav" href="client_change_name.php">
										<span class="title">Change Name</span>
									</a>
								</li>
								<li>
									<a href="client_change_password.php">
										<span class="title">Change Password</span>
									</a>
								</li>

							</ul>
						</li>	 -->

					</ul>
					</nav>
					<!-- end: MAIN NAVIGATION MENU -->
				</div>
				<!-- end: SIDEBAR -->
			</div>